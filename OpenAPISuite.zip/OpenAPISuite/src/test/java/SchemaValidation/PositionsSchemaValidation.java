package SchemaValidation;

import static org.hamcrest.Matchers.equalTo;
import static io.restassured.RestAssured.*;

import org.testng.Assert;
import org.testng.annotations.*;

import Base.Base;
import HelperMethods.HelperMethods;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class PositionsSchemaValidation extends Base {

	@BeforeTest
	public void setBaseURI() {
		Base b = new Base();
		b.setBaseURI("http://open.beta.fcstone.com/api/v1");
	}

	@Test
	public void getEODTrades() {
		Response rsp = 
		given().
		when().
			get("/trades/eod").
		then().
			log().
			all().
		extract().
			response();
		Assert.assertEquals(rsp.statusCode(), 200);

	}

	// Verify the 200 response code
	@Test
	public void checkStatusIs200() {
		HelperMethods hm = new HelperMethods();

	}

	// Verify Schema
	@Test
	public void givenUrl_whenJsonResponseConformsToSchema_thenCorrect() {
		given().
			contentType("application/json").
		when().
			get("/trades/eod").
		then().
			assertThat().
			body(matchesJsonSchemaInClasspath("JsonSchemaPosition.json")).log();
			
	}

	/*
	 * @Test public void EODTradesBody(){ RestAssured.baseURI =
	 * "http://open.beta.fcstone.com/api/v1/trades/eod"; RequestSpecification
	 * httpRequest = RestAssured.given(); Response response =
	 * httpRequest.get("/trades/eod");
	 * 
	 * // Retrieve the body of the Response ResponseBody body = response.getBody();
	 * 
	 * // To check for sub string presence get the Response body as a String. // Do
	 * a String.contains String bodyAsString = body.asString();
	 * Assert.assertEquals(bodyAsString.contains("totalRecords") Expected value,
	 * true Actual Value, "Total Records exists"); }
	 */
}
