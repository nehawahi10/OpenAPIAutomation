package Base;
import io.restassured.RestAssured;


public class Base {
	
	/*
	    ***Sets Base URI***
	    Before starting the test, we should set the RestAssured.baseURI
	    */
	    public static void setBaseURI (String baseURI){
	        RestAssured.baseURI = baseURI;
	    }

}
